package ui;

import java.io.FileNotFoundException;

//main runnable program
public class Main {
    public static void main(String[] args)  {
        try {
            new Chart();
        } catch (FileNotFoundException e) {
            System.out.println("Unable to run application: file not found");
        }
    }
}