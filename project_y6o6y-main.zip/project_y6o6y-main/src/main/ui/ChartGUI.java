package ui;

import model.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

import model.Event;
import model.EventLog;

// gui for the chart application
// code influenced by https://docs.oracle.com/javase/tutorial/uiswing/examples/components/index.html
public class ChartGUI extends JFrame  {
    private JTextField bar1amount;
    private JTextField bar2amount;
    private JTextField bar3amount;
    private JPanel chartPanel;
    private List<int[]> barChartDataList; // List to store bar chart data
    private int[] currentBars; // Array to store current bar values
    private DashBoard db;

    public ChartGUI() {
        // Initialize the dashboard
        this.db = new DashBoard();
        settings();

        // Initializing  the list and current bars
        intialization();


        // Panel to display the generated bar chart
        chartPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                display(g);
            }
        };
        chartPanel.setPreferredSize(new Dimension(900, 900));

        /*// Panel for buttons
        JPanel buttonPanel = makeBarPanel(generateButton, addButton, showListButton, showHighestAverageButton,
                saveButton, loadButton);*/

        // Add components to the frame
        components(makeBarPanel(), designPanel());

        // Set default close operation and size of the frame
        defaultClose();

        // Add a window listener for the close operation
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                printLogOnClose();
            }
        });

    }

    private JPanel designPanel() {
        // Create buttons for generating, displaying, showing average, loading, saving bar charts
        JButton generateButton = new JButton("Generate Chart");
        JButton addButton = new JButton("Add to Dashboard");
        JButton showListButton = new JButton("Show Dashboard");
        JButton showHighestAverageButton = new JButton("Show BarChart with Highest Average");
        JButton saveButton = new JButton("Save Data");
        JButton loadButton = new JButton("Load Data");


        // Adding action listeners for buttons
        action(generateButton, addButton, showListButton, showHighestAverageButton, saveButton, loadButton);

        JPanel buttonPanel = makeBarPanel(generateButton, addButton, showListButton, showHighestAverageButton,
                saveButton, loadButton);
        return buttonPanel;
    }

    private void designPanel(JButton generateButton, JButton addButton, JButton showListButton, JButton
            showHighestAverageButton, JButton saveButton, JButton loadButton, JPanel buttonPanel) {
        buttonPanel.add(generateButton);
        buttonPanel.add(addButton);
        buttonPanel.add(showListButton);
        buttonPanel.add(showHighestAverageButton);
        buttonPanel.add(saveButton);
        buttonPanel.add(loadButton);
    }

    //MODIFIES: this
    //EFFECTS: displays the barchart
    private void display(Graphics g) {
        if (currentBars != null) {
            drawBarChart(g, currentBars, barChartDataList.size() + 1);
        }
    }

    //MODIFIES: this
    //EFFECTS: initializes the barchart list
    private void intialization() {
        barChartDataList = new ArrayList<>();
        currentBars = new int[3];
    }

    //MODIFIES: this
    //EFFECTS: sets the base of the gui
    private void settings() {
        setTitle("Bar Chart GUI");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
    }

    //MODIFIES: this
    //EFFECTS: adds the button panels to the gui
    private void components(JPanel inputPanel, JPanel buttonPanel) {
        add(inputPanel, BorderLayout.NORTH);
        add(chartPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    //MODIFIES: this
    //EFFECTS: closes the application
    private void defaultClose() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(new Dimension(900, 300));
        setLocationRelativeTo(null); // Center on screen
        setVisible(true);
    }

    //MODIFIES: this
    // EFFECTS: forms the button panel
    private JPanel makeBarPanel(JButton generateButton, JButton addButton, JButton showListButton,
                                JButton showHighestAverageButton, JButton saveButton, JButton loadButton) {
        JPanel buttonPanel = new JPanel(new FlowLayout());

        // adds the buttons to the button panel
        designPanel(generateButton, addButton, showListButton, showHighestAverageButton, saveButton, loadButton,
                buttonPanel);
        return buttonPanel;
    }

    //MODIFIES: this
    //EFFECTS: getter method for bar panel
    private JPanel makeBarPanel() {
        JPanel inputPanel = new JPanel();

        //sets the JTextField for the bars
        barAmounts();

        // adds the bar amounts to bar 1 , bar 2 , bar 3
        addBar(inputPanel);
        return inputPanel;
    }

    private void addBar(JPanel inputPanel) {
        inputPanel.add(new JLabel("Bar 1:"));
        inputPanel.add(bar1amount);
        inputPanel.add(new JLabel("Bar 2:"));
        inputPanel.add(bar2amount);
        inputPanel.add(new JLabel("Bar 3:"));
        inputPanel.add(bar3amount);
    }



    private void barAmounts() {
        bar1amount = new JTextField(5);
        bar2amount = new JTextField(5);
        bar3amount = new JTextField(5);
    }

    //MODIFIES: this
    //EFFECTS: adds actions to each button
    private void action(JButton generateButton, JButton addButton, JButton showListButton,
                        JButton showHighestAverageButton, JButton saveButton, JButton loadButton) {
        generateButton.addActionListener(this::generateAndDisplayChart);
        addButton.addActionListener(this::addChartToList);
        showListButton.addActionListener(this::showChartList);
        showHighestAverageButton.addActionListener(this::showChartWithHighestAverage);
        saveButton.addActionListener(this::saveChartData);
        loadButton.addActionListener(this::loadChartData);
    }


    //MODIFIES: this
    //EFFECTS: generates and displays the chart
    private void generateAndDisplayChart(ActionEvent e) {
        try {
            currentBars[0] = Integer.parseInt(bar1amount.getText());
            currentBars[1] = Integer.parseInt(bar2amount.getText());
            currentBars[2] = Integer.parseInt(bar3amount.getText());
            repaint();
        } catch (NumberFormatException nfe) {
            JOptionPane.showMessageDialog(this, "Please enter valid numbers for all bars.");
        }
    }

    //MODIFIES: this
    //EFFECTS: adds chart to the dashboard
    private void addChartToList(ActionEvent e) {

        ImageIcon icon = new ImageIcon("data/Success.png");
        if (currentBars != null) {
            // Create a new BarChart object
            BarChart newChart = new BarChart(
                    String.valueOf(currentBars[0]),
                    String.valueOf(currentBars[1]),
                    String.valueOf(currentBars[2])
            );

            // Add the new chart to the dashboard
            db.addChart(newChart);
            barChartDataList.add(currentBars.clone()); // Add a clone/replica of the current bars to the list
            currentBars = new int[3]; // Reset current bars
            JOptionPane.showMessageDialog(this, "Current bar chart added to list.",
                    "Chart Added", JOptionPane.INFORMATION_MESSAGE, icon);
        }
    }


    //MODIFIES: this
    //EFFECTS: displays the charts in the dashboard
    private void showChartList(ActionEvent e) {
        // Create a dialog to display the list of bar charts
        JDialog dialog = new JDialog(this, "List of Bar Charts");
        dialog.setLayout(new FlowLayout());
        dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        conditionForLoop(dialog);
        // Use the getBarcharts method from DashBoard to get the string representation
        String barchartListString = db.getBarcharts();

        // Create a text area to display the bar charts
        JTextArea textArea = new JTextArea(barchartListString);
        textArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new Dimension(800, 200));

        // Add the scroll pane containing the text area to the dialog
        dialog.add(scrollPane, BorderLayout.CENTER);

        // Pack and display the dialog
        dialog.pack();
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }

    private void conditionForLoop(JDialog dialog) {
        for (int i = 0; i < barChartDataList.size(); i++) {
            int[] bars = barChartDataList.get(i);
            int finalI = i;
            JPanel barChartPanel = new JPanel() {
                @Override
                protected void paintComponent(Graphics g) {
                    super.paintComponent(g);
                    drawBarChart(g, bars, finalI + 1);
                }
            };
            barChartPanel.setPreferredSize(new Dimension(800, 200));
            dialog.add(barChartPanel);
        }
    }

    //MODIFIES: this
    //EFFECTS: draws the charts
    private void drawBarChart(Graphics g, int[] bars, int chartNumber) {
        // Assume the panel has enough space on top and bottom
        int panelHeight = chartPanel.getHeight() - 40; // Deducting some space for the top label and bottom axis labels
        int panelWidth = chartPanel.getWidth();

        // Calculate the maximum bar height for scaling the bars
        int maxBarHeight = 0;
        maxBarHeight = getMaxBarHeight(bars, maxBarHeight);

        // Define the width of each bar and the space between bars
        int barWidth = (panelWidth - (bars.length + 1) * 20) / bars.length;
        // Subtract spaces and divide by number of bars
        int spaceBetweenBars = 20;

        // Colors for the bars
        Color[] barColors = {Color.RED, Color.ORANGE, Color.CYAN, Color.MAGENTA};

        // Draw the bars
        for (int i = 0; i < bars.length; i++) {
            int x = (i + 1) * spaceBetweenBars + i * barWidth;
            int barHeight = (int) (((double) bars[i] / maxBarHeight) * (panelHeight - 40)); // Subtract space for labels
            int y = panelHeight - barHeight;

            // Set color and draw the bar
            g.setColor(barColors[i % barColors.length]);
            g.fillRect(x, y, barWidth, barHeight);

            // Draw the label for each bar
            g.setColor(Color.BLACK);
            String label = "Bar " + (i + 1);
            g.drawString(label, x + (barWidth - g.getFontMetrics().stringWidth(label)) / 2, panelHeight + 15);
        }

        // Draw the chart number label at the top
        g.setColor(Color.BLACK);
        g.drawString("Bar Chart #" + chartNumber, 5, 15);
    }

    //MODIFIES: this
    //EFFECTS: gets maximum height of a bar
    private int getMaxBarHeight(int[] bars, int maxBarHeight) {
        for (int bar : bars) {
            maxBarHeight = Math.max(maxBarHeight, bar);
        }
        return maxBarHeight;
    }

    //MODIFIES: this
    //EFFECTS: shows chart with highest average of bar length
    private void showChartWithHighestAverage(ActionEvent e) {
        BarChart chartWithHighestAverage = db.findChartWithHighestAverage();

        if (chartWithHighestAverage == null) {
            JOptionPane.showMessageDialog(this, "No charts in the list to display.");
            return;
        }

        // Assuming each bar value is stored as a string and needs to be parsed as an integer
        currentBars[0] = Integer.parseInt(chartWithHighestAverage.getBar1());
        currentBars[1] = Integer.parseInt(chartWithHighestAverage.getBar2());
        currentBars[2] = Integer.parseInt(chartWithHighestAverage.getBar3());

        repaint();
    }

    //EFFECTS: saves the chart data
    private void saveChartData(ActionEvent e) {
        try {
            // Open a file chooser to save the file
            JFileChooser fileChooser = new JFileChooser();
            int option = fileChooser.showSaveDialog(this);
            if (option == JFileChooser.APPROVE_OPTION) {
                File file = fileChooser.getSelectedFile();
                // Write data to the file
                try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(file))) {
                    out.writeObject(barChartDataList);
                }
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error saving file: " + ex.getMessage());
        }
    }

    //MODIFIES: this
    //EFFECTS: loads the chart data
    private void loadChartData(ActionEvent e) {
        try {
            // Open a file chooser to load the file
            JFileChooser fileChooser = new JFileChooser();
            int option = fileChooser.showOpenDialog(this);
            if (option == JFileChooser.APPROVE_OPTION) {
                File file = fileChooser.getSelectedFile();
                // Read data from the file
                try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(file))) {
                    barChartDataList = (List<int[]>) in.readObject();
                }
            }
        } catch (IOException | ClassNotFoundException ex) {
            JOptionPane.showMessageDialog(this, "Error loading file: " + ex.getMessage());
        }
    }


    // EFFECTS: main runnable gui
    public static void main(String[] args) {
        SwingUtilities.invokeLater(ChartGUI::new);
    }


    //EFFECTS: prints the required log on console
    private void printLogOnClose() {
        EventLog log = EventLog.getInstance();
        for (Event event : log) {
            System.out.println(event);
        }
    }


}