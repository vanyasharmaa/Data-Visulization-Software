package ui;

import model.BarChart;
import model.DashBoard;
import java.util.Scanner;

import persistence.JsonReader;
import persistence.JsonWriter;

import java.io.FileNotFoundException;
import java.io.IOException;


// makes the the chart program run , where barcharts can be made, displayed,loaded,added to dashboard
public class Chart {

    //fields
    private static final String JSON_STORE = "./data/dashboard.json";
    private Scanner input;
    private BarChart barChart;
    private DashBoard newList;
    private JsonWriter jsonWriter;
    private JsonReader jsonReader;
    private int bar3;
    private int bar2;
    private int bar1;

    //runs the charts app
    public Chart() throws FileNotFoundException {
        input = new Scanner(System.in);
        jsonWriter = new JsonWriter(JSON_STORE);
        jsonReader = new JsonReader(JSON_STORE);
        runChart();

    }

    // MODIFIES: this
    // EFFECTS: processes user input
    private void runChart() {
        boolean keepGoing = true;
        String command = null;

        //  init(); // initialization
        input = new Scanner(System.in);
        input.useDelimiter("\n");
        newList = new DashBoard();

        while (keepGoing) {
            displayMenu();
            command = input.next();
            command = command.toLowerCase();

            if (command.equals("q")) {
                keepGoing = false;
            } else {
                processCommand(command);
            }
        }

        System.out.println("\nGoodbye!");
    }

    // MODIFIES: this
    // EFFECTS: processes user command
    private void processCommand(String command) {
        if (command.equals("b")) {
            graph();
        }  else if (command.equals("d")) {
            displayDashboard();
        } else if (command.equals("n")) {
            itemsInDasBoard();
        } else if (command.equals("s")) {
            saveDashboard();
        } else if (command.equals("l")) {
            loadDashbaord();
        } else if (command.equals("y")) {
            System.out.println("The maximum length of a bar is " + Math.max(Math.max(bar1, bar2), bar3));
        } else {
            System.out.println("TRY AGAIN!");
        }
    }


    // EFFECTS: displays menu of options to user
    private void displayMenu() {
        System.out.println("\nSelect from:");
        System.out.println("\tb -> New Barchart");
        System.out.println("\tq -> quit"); // add to dash ????
        System.out.println("\td -> Display Dashboard");
        System.out.println("\tn -> Number of Barcharts in the dashboard ");//
        System.out.println("\ts -> save Barchart to file");
        System.out.println("\tl -> load Barchart from file");
        System.out.println("\ty -> Longest Bar in the barchart ");//

    }

    // EFFECTS: displays the Bar charts present in Dashboard to user
    private void displayDashboard() { ///
        {
            System.out.println("Barcharts: \n" + newList.getBarcharts());
        }
    }

    // EFFECTS: displays the number of  Bar charts present in Dashboard to user
    private void itemsInDasBoard() {
        System.out.println("DasBoard has " + newList.getNumberOfBarcharts() +   " Bar Chart(s)");
    }

    //MODIFIES: Dashboard,Barchart
    //EFFECTS: makes Bar charts according to user input and adds it to Dashboard
    private void graph() {
        String graphBar1;
        String graphBar2;
        String graphBar3;

        System.out.print("Enter length of Bar1 >> ");
        bar1 = input.nextInt();
        System.out.print("Enter length of Bar2 >> ");
        bar2 = input.nextInt();
        System.out.print("Enter length of Bar3 >> ");
        bar3 = input.nextInt();
        System.out.println();
        System.out.println("-----BAR CHART -----"); //
        System.out.println();
        System.out.print("Bar1   ");
        graphBar1 = BarChart.makeBar(bar1);
        System.out.print("Bar2   ");
        graphBar2 = BarChart.makeBar(bar2);
        System.out.print("Bar3   ");
        graphBar3 = BarChart.makeBar(bar3);

        barChart = addtoDashboard(graphBar1,graphBar2,graphBar3);
    }

    //MODIFIES:Dashboard
    //EFFECTS: makes and adds the barchart of given values to Dashboard
    public BarChart addtoDashboard(String bar1, String bar2, String bar3) {
        barChart = new BarChart(bar1,bar2,bar3);
        newList.addChart(barChart);
        return barChart;
    }

    // EFFECTS: saves the dashboard to file
    private void saveDashboard() {
        try {
            jsonWriter.open();
            jsonWriter.write(newList);
            jsonWriter.close();
            System.out.println("Saved " + " to " + JSON_STORE);
        } catch (FileNotFoundException e) {
            System.out.println("Unable to write to file: " + JSON_STORE);
        }
    }

    // MODIFIES: this
    // EFFECTS: loads dashboard from file
    private void loadDashbaord() {
        try {
            newList = jsonReader.read();
            System.out.println("Loaded " + " from " + JSON_STORE);
        } catch (IOException e) {
            System.out.println("Unable to read from file: " + JSON_STORE);
        }
    }


}






