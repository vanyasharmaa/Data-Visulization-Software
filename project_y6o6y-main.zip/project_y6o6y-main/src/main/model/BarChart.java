package model;

import org.json.JSONObject;
import persistence.Writable;

// makes a barchart that contains 3 bars bar 1, bar 2 , bar 3 of string type
public class BarChart implements Writable {

    //fields
    private String bar1;
    private String bar2;
    private String bar3;

    //EFFECTS: constructs a bar chart
    public BarChart(String bar1,String bar2, String bar3) {
        this.bar1 = bar1;
        this.bar2 = bar2;
        this.bar3 = bar3;
    }

    public String getBar1() {
        return bar1;
    }

    public String getBar2() {
        return bar2;
    }

    public String getBar3() {
        return bar3;
    }

    //MODIFIES: this
    //EFFECTS: for every positive integer makes a bar where 1 = "|"
    public static String makeBar(int l) {
        int length;
        String temp = "";
        for (length = 0; length < l; length++) {
            temp += "|";

        }
        System.out.println(temp);
        return temp;
    }

    // Code influenced by the JsonSerizalizationDemo https://github.students.cs.ubc.ca/CPSC210/JsonSerializationDemo
    //EFFECTS: returns json object containing  bar1, bar2, bar3
    @Override
    public JSONObject toJson() {
        JSONObject json = new JSONObject();
        json.put("bar1", bar1);
        json.put("bar2", bar2);
        json.put("bar3", bar3);
        return json;
    }

}

