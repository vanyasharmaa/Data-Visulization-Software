package model;

import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONObject;
import persistence.Writable;
import java.util.Collections;
import java.util.List;

// contains the list of barcharts made by the user
public class DashBoard implements Writable {
    private final List<BarChart> listofCharts;


    //EFFECTS: Constructs an arraylist to store barcharts
    public DashBoard() {
        listofCharts = new ArrayList<>();
    }

    // REQUIRES: BarChart
    // MODIFIES: this
    // EFFECTS:  Adds the barchart to the Dashboard
    public void addChart(BarChart barChart) {
        listofCharts.add(barChart);
        EventLog.getInstance().logEvent(new Event("Barchart is added to the dashboard"));
    }


    //REQUIRES: BarChart
    //MODIFIES: this
    //EFFECTS: return true if the required barchart is in the dashboard
    //         else return false
    public boolean containsBarChart(BarChart barChart) {
        return listofCharts.contains(barChart);
    }

    //REQUIRES: BarChart
    //MODIFIES: this
    //Effects: returns false and removes the given barchart in the dashboard
    //         else return true
    public boolean removeBarChart(BarChart barChart) {
        if (containsBarChart(barChart)) {
            listofCharts.remove(barChart);
            return false;
        } else {
            return true;
        }
    }

    //EFFECTS: returns the number of Bar Charts in this Dashboard
    public int getNumberOfBarcharts() {
        return listofCharts.size();
    }

    // EFFECTS: returns an unmodifiable list of Barcharts in this Dashboard
    public List<BarChart> getListOfBarcharts() {
        return Collections.unmodifiableList(listofCharts);
    }

    // EFFECTS: lists all Bar Charts in the dashboard
    public String getBarcharts() {
        String barcharts = "";
        for (int i = 0; i < getNumberOfBarcharts(); i++) {
            barcharts += "Barchart #" + (i + 1) + "\n" + listofCharts.get(i).getBar1()
                    + "\n" + listofCharts.get(i).getBar2() + "\n"
                    + listofCharts.get(i).getBar3() + "\n";
        }
        EventLog.getInstance().logEvent(new Event(" barchart(s) are displayed in the dashboard"));
        return barcharts;

    }

    // EFFECTS:  to find and return the bar chart with the highest average
    public BarChart findChartWithHighestAverage() {
        if (listofCharts.isEmpty()) {
            return null;
        }

        BarChart chartWithHighestAverage = null;
        double highestAverage = 0;

        for (BarChart chart : listofCharts) {
            double average = (Integer.parseInt(chart.getBar1())
                    +
                    Integer.parseInt(chart.getBar2())
                    +
                    Integer.parseInt(chart.getBar3())) / 3.0;

            if (average > highestAverage) {
                highestAverage = average;
                chartWithHighestAverage = chart;
            }
        }

        EventLog.getInstance().logEvent(new Event("Chart with highest average accessed"));
        return chartWithHighestAverage;
    }


    // Code influenced by the JsonSerizalizationDemo https://github.students.cs.ubc.ca/CPSC210/JsonSerializationDemo
    //EFFECTS: returns json object containing listofCharts
    @Override
    public JSONObject toJson() {
        JSONObject json = new JSONObject();
        json.put("listofCharts", barchartsToJson());
        return json;
    }

    // Code influenced by the JsonSerizalizationDemo https://github.students.cs.ubc.ca/CPSC210/JsonSerializationDemo
    // EFFECTS: returns Bar Charts in this DashBoard as a JSON array
    private JSONArray barchartsToJson() {
        JSONArray jsonArray = new JSONArray();

        for (BarChart b : listofCharts) {
            jsonArray.put(b.toJson());
        }
        return jsonArray;
    }

}












