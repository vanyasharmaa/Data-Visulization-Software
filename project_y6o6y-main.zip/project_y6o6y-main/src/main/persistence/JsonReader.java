package persistence;

import model.BarChart;
import model.DashBoard;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.stream.Stream;

import org.json.*;

// Code influenced by the JsonSerizalizationDemo https://github.students.cs.ubc.ca/CPSC210/JsonSerializationDemo
// Represents a reader that reads Dashboard from JSON data stored in file
public class JsonReader {
    private String source;

    // EFFECTS: constructs reader to read from source file
    public JsonReader(String source) {
        this.source = source;
    }

    // EFFECTS: reads Dashboard from file and returns it;
    // throws IOException if an error occurs reading data from file
    public DashBoard read() throws IOException {
        String jsonData = readFile(source);
        JSONObject jsonObject = new JSONObject(jsonData);
        return parseDashboard(jsonObject);
    }

    // EFFECTS: reads source file as string and returns it
    private String readFile(String source) throws IOException {
        StringBuilder contentBuilder = new StringBuilder();

        try (Stream<String> stream = Files.lines(Paths.get(source), StandardCharsets.UTF_8)) {
            stream.forEach(s -> contentBuilder.append(s));
        }

        return contentBuilder.toString();
    }

    // EFFECTS: parses Dashboard from JSON object and returns it
    private DashBoard parseDashboard(JSONObject jsonObject) {
        DashBoard d = new DashBoard();
        addBarcharts(d, jsonObject);
        return d;
    }


    // MODIFIES: DashBoard d
    // EFFECTS: parses listofCharts from JSON object and adds them to DashBoard
    private void addBarcharts(DashBoard d, JSONObject jsonObject) {
        JSONArray jsonArray = jsonObject.getJSONArray("listofCharts");
        for (Object json : jsonArray) {
            JSONObject nextThingy = (JSONObject) json;
            addBarchart(d, nextThingy);
        }
    }

    // MODIFIES: DashBoard d
    // EFFECTS: parses BarChart from JSON object and adds it to DashBoard
    private void addBarchart(DashBoard d, JSONObject jsonObject) {
        String bar1 = jsonObject.getString("bar1");
        String bar2 = jsonObject.getString("bar2");
        String bar3 = jsonObject.getString("bar3");
        BarChart barchart = new BarChart(bar1,bar2,bar3);///////////
        d.addChart(barchart);
    }
}