
package model;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

// BarChart tests
public class BarChartTest {


    BarChart barChart;
    private String bar1;
    private String bar2;
    private String bar3;


    @BeforeEach
    public void setup() {
        barChart = new BarChart(bar1,bar2,bar3);
    }

    @Test
    public void testgetBar1(){
        assertEquals(barChart.getBar1(),bar1);
    }

    @Test
    public void testgetBar2(){
        assertEquals(barChart.getBar2(),bar2);
    }

    @Test
    public void testgetBar3(){
        assertEquals(barChart.getBar3(),bar3);
    }

    @Test
    public void TestZeroLengthBar() {
        String bar0 = barChart.makeBar(0);
        assertEquals(bar0, "");
    }


    @Test
    public void TestPositiveLength(){
        String barPositive = barChart.makeBar(5);
        assertEquals(barPositive, "|||||");
    }


    @Test
    public void TestNegativeLength(){
        String barNegative = barChart.makeBar(-4);
        assertEquals(barNegative, "");
    }

    @Test
    public void TestPositiveEdge(){
        String bar1 = barChart.makeBar(1);
        assertEquals(bar1, "|");
    }

    @Test
    public void TestNegativeEdge(){
        String barNegativeEdge = barChart.makeBar(-1);
        assertEquals(barNegativeEdge, "");
    }
}



