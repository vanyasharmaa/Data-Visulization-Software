
package model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

// Dashboard Tests
class DashBoardTest {
    private DashBoard test1;
    private BarChart barChart;
    private String bar1;
    private String bar2;
    private String bar3;


    @BeforeEach
    public void runBefore(){
        test1 = new DashBoard();
        barChart = new BarChart(bar1,bar2,bar3);
    }

    @Test
    public void testAddChart(){
        test1.addChart(barChart);
        assertTrue(test1.containsBarChart(barChart));
    }

    @Test
    public void testRemoveBarChart(){
        test1.addChart(barChart);
        assertFalse(test1.removeBarChart(barChart));
        test1.removeBarChart(barChart);
        assertFalse(test1.containsBarChart(barChart));
    }

    @Test
    public void testgetNumberOfBarcharts(){
        test1.addChart(barChart);
        test1.addChart(barChart);
        test1.addChart(barChart);
        assertEquals(3,test1.getNumberOfBarcharts());

    }


}

