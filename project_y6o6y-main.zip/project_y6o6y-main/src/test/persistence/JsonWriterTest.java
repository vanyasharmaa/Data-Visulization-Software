package persistence;

import model.BarChart;
import model.DashBoard;
import org.junit.jupiter.api.Test;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;

// Json Writer Tests
// Code influenced by the JsonSerizalizationDemo https://github.students.cs.ubc.ca/CPSC210/JsonSerializationDemo
class JsonWriterTest {
    //NOTE TO CPSC 210 STUDENTS: the strategy in designing tests for the JsonWriter is to
    //write data to a file and then use the reader to read it back in and check that we
    //read in a copy of what was written out.

    @Test
    void testWriterInvalidFile() {
        try {
            DashBoard d = new DashBoard();
            JsonWriter writer = new JsonWriter("./data/my\0illegal:fileName.json");
            writer.open();
            fail("IOException was expected");
        } catch (IOException e) {
            // pass
        }
    }

    @Test
    void testWriterEmptyDashboard() {
        try {
            DashBoard d = new DashBoard();
            JsonWriter writer = new JsonWriter("./data/testWriterEmptyDashboard.json");
            writer.open();
            writer.write(d);
            writer.close();

            JsonReader reader = new JsonReader("./data/testWriterEmptyDashboard.json");
            d = reader.read();
            assertEquals(0, d.getNumberOfBarcharts());
        } catch (IOException e) {
            fail("Exception should not have been thrown");
        }
    }


    @Test
    void testWriterGeneralDashboard(){
        try {
           DashBoard d = new DashBoard();
           BarChart barchart1 = new BarChart("|","||","|||");
           d.addChart(barchart1);
           BarChart barchart2 = new BarChart("|||||","||","|||");
           d.addChart(barchart2);
           JsonWriter writer = new JsonWriter("./data/testWriterGeneralDashboard.json");
           writer.open();
           writer.write(d);
           writer.close();

           JsonReader reader = new JsonReader("./data/testWriterGeneralDashboard.json");
            d = reader.read();
            assertEquals(d.getBarcharts(),"Barchart #" + 0 + "\n" + barchart1.getBar1()
                    + "\n" + barchart1.getBar2() + "\n"
                    + barchart1.getBar3() + "\n" + "Barchart #" + 1 + "\n" + barchart2.getBar1()
                    + "\n" + barchart2.getBar2() + "\n"
                    + barchart2.getBar3() + "\n" );


        } catch (IOException e) {
            fail("Exception should not have been thrown");
        }
    }

    }
