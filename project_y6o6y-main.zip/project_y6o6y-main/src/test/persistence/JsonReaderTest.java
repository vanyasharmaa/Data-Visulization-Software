package persistence;

import model.BarChart;
import model.DashBoard;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

// Json Reader tests
// Code influenced by the JsonSerizalizationDemo https://github.students.cs.ubc.ca/CPSC210/JsonSerializationDemo
class JsonReaderTest {

    @Test
    void testReaderNonExistentFile() {
        JsonReader reader = new JsonReader("./data/noSuchFile.json");
        try {
            DashBoard d = reader.read();
            fail("IOException expected");
        } catch (IOException e) {
            // pass
        }
    }

    @Test
    void testReaderEmptyDashboard() {
        JsonReader reader = new JsonReader("./data/testReaderEmptyDashboard.json");
        try {
            DashBoard d = reader.read();
            assertEquals(0, d.getNumberOfBarcharts());
        } catch (IOException e) {
            fail("Couldn't read from file");
        }
    }


    @Test
    void testReaderGeneralDashboard() {
        JsonReader reader = new JsonReader("./data/testReaderGeneralDashboard.json");
        try {
             DashBoard d = reader.read();
             List<BarChart> listofCharts = d.getListOfBarcharts();
             assertEquals(2, listofCharts.size());
        } catch (IOException e) {
            fail("Couldn't read from file");
        }
    }
}