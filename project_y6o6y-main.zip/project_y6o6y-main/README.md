# **DataSnap: Click & Unleash Your Inner Data Wizard**

## About us!

DataSnap is an **_*online data visualization and storage software*_** designed to facilitate the representation of data through
various chart types, including bar charts, line charts, histograms,scatterplots, and pie charts. 
It enables the creation and management of customized dashboards tailored to the unique data analysis needs of businesses
and organizations, facilitating well-informed and efficient decision-making based on company data.

Motivation: As a Statistics major with a concentration in Computer Science, my project 
concept for DataSnap is a fusion
of my academic disciplines. It goes beyond classroom learning to deliver a practical utility 
relevant to both Statistics and Computer Science majors. With aspirations in the field of data 
science and analytics, I have harbored a profound curiosity about the software and packages 
employed for data visualization. Enrolling in CPSC 210 has provided me with the opportunity to
delve deeper into the inner workings of various visualization software tools.

USER STORIES:

- As a user, I want to be able to create arbitrary  visualization plots and add it to company dashboard
- As a user, I want to be able to view the plots that are added to the company Dashboard.
- As a user, I want to be able to view the number of plots present in  the Dashboard.
- As a user, I want to be able to know the length of the longest bar in the barchart.
- As a user, I want to be able to save my company Dashboard.(If I so choose).
- As a user, I want to be able to load my company Dashboard.(If I so choose).
- As a user, I want to be able to make a new barchart that contains the barchart with
  the highest average of bars added on the dashboard.

# Instructions for Grader

- You can generate barcharts by inputting values for Bar 1 , Bar 2 , Bar 3 and then click
  "Generate Chart" button
- You can add multiple barcharts to the dashboard by clicking the "Add to Dashboard" button.
- You can view the generated/current Barchart on the panel displayed (it's automatic).(visual comp)
- You can view the list of barcharts that have been added to Dashboard by clicking 
  "Show Dashboard" button. (visual comp)-
- You can save the state of my application by clicking the "Save Data" button.
- You can reload the state of my application by clicking the "Load Data" button
- You can generate a new barchart which contains the barchart with the highest average of bars 
  added on the dashboard.
  
# Phase 4: Task 2
 - Tue Nov 28 17:46:47 PST 2023
 - Barchart is added to the dashboard
 - Tue Nov 28 17:46:49 PST 2023
 - barchart(s) are displayed in the dashboard
 - Tue Nov 28 17:46:51 PST 2023
 - Chart with highest average accessed

# Phase 4: Task 3
Refactoring:
I would have a separate class that constructs a Chart in the model class; this would become
my super class. I would then have Barchart extend Chart , this way I could potentially
increase the functionality of my project by having more Classes like ScatterPlot, Histogram etc
These can then extend the Chart and override the required methods to form the plots described above.

A simple Refactor where I simply had a chart class (super class) , and have Barchart (subtype)
extend it , could not only simplify the working of the current project, but also
make it easier for future developers to read and understand the project and add new features
like different types of plots.


